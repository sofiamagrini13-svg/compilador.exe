const musica = document.getElementById("musica");

const btnTocar = document.getElementById("btnTocar");
const btnParar = document.getElementById("btnParar");

btnTocar.addEventListener("click", function() {
    musica.play();
});

btnParar.addEventListener("click", function() {
    musica.pause();
    musica.currentTime = 0;
});